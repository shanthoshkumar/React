import { useEffect, useState } from "react"

const Item = (category, description, image ) => {
    return {
        category, description, image
    }
}
const list =[
    Item('Shoulder Bags', 'Bags for Women', 'https://images.unsplash.com/photo-1511405946472-a37e3b5ccd47?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8Mnx8c2hvdWxkZXIlMjBiYWclMjBmb3IlMjB3b21lbnxlbnwwfHwwfHw%3D&auto=format&fit=crop&w=800&q=60'),
    Item('Shoulder Bags', 'Bags for men','https://images.unsplash.com/photo-1553062407-98eeb64c6a62?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8Mnx8YmFnfGVufDB8fDB8fA%3D%3D&auto=format&fit=crop&w=800&q=60'),
    Item('Backpag Bags', 'Bags for all', 'https://images.unsplash.com/photo-1656078253923-dad3d33a12b4?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8MjB8fEJhY2twYWclMjBCYWdzfGVufDB8fDB8fA%3D%3D&auto=format&fit=crop&w=800&q=60'),
    Item('Sling Bags','Bags for all','https://images.unsplash.com/photo-1511405946472-a37e3b5ccd47?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=774&q=80'),
    Item('Laptop Bags', 'Bags for both men and women','https://media.istockphoto.com/id/1173223219/photo/modern-laptop-bag.jpg?b=1&s=170667a&w=0&k=20&c=3aFQkrF_TZr73byrzEDIKG5MykM9yb3HbpbgHmohf-U='),
    Item('School Bags', 'Bags for students', 'https://images.unsplash.com/photo-1622560480605-d83c853bc5c3?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8NHx8U2Nob29sJTIwQmFnc3xlbnwwfHwwfHw%3D&auto=format&fit=crop&w=800&q=60'),
    Item('Cricket Bat', 'Bat', 'https://plus.unsplash.com/premium_photo-1678033331726-0f02fe52b195?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8N3x8Y3JpY2tldCUyMGJhdHxlbnwwfHwwfHw%3D&auto=format&fit=crop&w=800&q=60')

]

const Search = () => {
    const [searchText, setSearchText]=useState('');
    const [suggestionList, setSuggestionList]=useState([]);

    useEffect(() => {
        if(searchText !== ''){
        const filteredItems = list.filter(item => item.category.toLowerCase().includes(searchText.toLowerCase()))
        setSuggestionList([...filteredItems]);
        }
    },[searchText])

    const debounce = (callbackFn ,delay = 1000) => {
        let timeout;
        return (...args) => {
            clearTimeout(timeout)
            timeout = setTimeout(() => callbackFn(...args), delay)
        }
    }

    const changeHandler = debounce(text => setSearchText(text),0);

    const fetchPage = (item) => {
        console.log(item);
    }

    return <div>
        <input type='text' onChange={(e) => changeHandler(e.target.value)}/>
        <ul>
            {suggestionList.map((suggestion, index) => {
                return <li key={index} onClick={(e) => fetchPage(e.target.textContent)}>
                    <img src={suggestion.image}/>
                    <div className="meta-info">
                        <span>{suggestion.category}</span>
                        <span className="description">in {suggestion.description}</span>
                    </div>
                </li>
            })}
        </ul>
    </div>
}

export default Search