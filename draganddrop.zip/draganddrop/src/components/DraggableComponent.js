import { useState } from "react";

const DraggableComponent = (props) => {
    const [showChildren, setShowChildren] = useState(false)
    const dragStart = (e) => {
        e.preventDefault()
        setShowChildren(false)
        console.log(showChildren)
    }

    const drag = (e) => {
        e.preventDefault()
        setShowChildren(false)
    }

    const dragEnd = (e) => {
        e.preventDefault()
        setShowChildren(true)
    }

    return  <div className='box' onDragOver={dragStart} onDragLeave={drag} onDrop={dragEnd}>
        {showChildren && <img src={require('../ball.png')} />}
    </div>
}

export default DraggableComponent;