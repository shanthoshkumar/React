import logo from './logo.svg';
import './App.css';
import DraggableComponent from './components/DraggableComponent';
function App() {
  return (
    <div className="App">
     <div className='container'>
      <DraggableComponent>
      </DraggableComponent>
      <DraggableComponent/>
      <DraggableComponent/>
      <DraggableComponent/>
     </div>
    </div>
  );
}

export default App;
