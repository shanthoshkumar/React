import logo from './logo.svg';
import './App.css';
import { useState } from 'react';

function App() {


  const items = [
    "Angular",
    "Hello",
    "Goodbye",
    "React",
    "Node",
    "Mongodb"
  ]
  const [prefix, setPrefix] = useState("")
  const [suggested, setSuggested] = useState(items.join())
  const [elements, setElements] = useState([])

  const changeHandler = (e) => {
    const value = `${e.target.value}`.length === 0 ? " ": e.target.value
    setPrefix(value)
    if(value.trim().length){
      const item = items.find(item => {
        // console.log(item.toLowerCase()+'-'+ value.toLowerCase()+'-'+ item.toLowerCase().startsWith(value.trim().toLowerCase()));
      return  item.toLowerCase().startsWith(value.trim().toLowerCase()) ? true : false
      })
      setSuggested(item);
      setElements([...item.substring(value.length, item.length).split("")])
      return;
    }
    setSuggested(items.join())
  }


  return (
    <div className="App">
      <input type='text' name="search-bar" id='search-bar' placeholder='Search...' onChange={changeHandler}/>
      <h1>{suggested}</h1>
      <div>
        {<span>{prefix}</span>}
        {
        elements.map(((char, index) => <span key={index} style={{color: 'lightgrey'}}>{char}</span>))
        }</div>
    </div>
  );
}

export default App;
