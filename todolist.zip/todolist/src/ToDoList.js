import { useState } from 'react';
import ToDoElement from './ToDoElement';

const ToDoList = () => {
    const [items, setItems] = useState([]);
    const addToDoElement = (e) => {
        setItems([...items, { index: items.length ? items[items.length - 1].index + 1 : 0, value: e.target.value }])
    };

    const addToDo = (index, todo) => {
        const updatedList = items.map(item => item.index === index ? { ...item, value: todo } : item);
        setItems(updatedList)
    };

    const deleteToDo = (index) => {
        const filteredItems = items.filter(item => item.index != index);
        setItems(filteredItems);
    }

    return (<div>
        <h1>ToDo List</h1>
        <button onClick={addToDoElement}>Add a todo</button>
        <div style={{ marginTop: '10px' }}>
            {
                JSON.stringify(items)
            }
            {
                items.map((item) => <ToDoElement key={item.index} addToDo={addToDo} deleteToDo={deleteToDo} index={item.index} value={item.value} />)
            }
        </div>
    </div>)
}

export default ToDoList;