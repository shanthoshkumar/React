import {useState} from 'react';
// Working Method 
// const ToDoElement = ({addToDo, editToDo, deleteToDo, index, value}) => {
//     const [todoValue, setTodo] = useState();
//     const [isDisabled, setDisabled] = useState(value ? true : false);
//     const operateToDo = (status) =>{
//         addToDo(index, todoValue)
//         setDisabled(!isDisabled);
//     }
//     return (<div style={{ marginTop: '10px' }}>
//         <input type='text' value={todoValue} onChange={(e) => setTodo(e.target.value)} disabled={isDisabled} />
//         <button style={{ marginLeft: '10px' }} onClick={operateToDo}>{value ? "Edit" : "Add"}</button>
//         <button style={{ marginLeft: '10px' }} onClick={() => deleteToDo(index)}>Delete</button>
//         </div>)
// }

// Alternate Implementation using Form

const ToDoElement = ({addToDo, editToDo, deleteToDo, index, toDoValue}) => {
    const [isDisabled, setDisabled] = useState(toDoValue ? true : false);

    const formHandler = (e) => {
        addToDo(index, e.target.name.value)
        setDisabled(!isDisabled);
        e.preventDefault();
    }
    return (<form style={{ marginTop: '10px' }} onSubmit={formHandler}>
        <input type='text' name="name" disabled={isDisabled} />
        <button type="submit" style={{ marginLeft: '10px' }}>{isDisabled ? "Edit" : "Save"}</button>
        <button style={{ marginLeft: '10px' }} onClick={() => deleteToDo(index)}>Delete</button>
        </form>)
}

export default ToDoElement;