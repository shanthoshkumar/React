export const initialState = {
    loading: false,
    users: [],
    error: ""
}