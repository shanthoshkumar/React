import axios from "axios"
import { FETCH_FAILURE, FETCH_SUCCESS, FETCH_USERS } from "./constants"

const fetchUsers = () => {
    return {
        type: FETCH_USERS
    }
}

const fetchSuccess = users => {
    return {
        type: FETCH_SUCCESS,
        users
    }
}

const fetchFailure = error => {
    return {
        type: FETCH_FAILURE,
        error
    }
}


const fetchAll = () => {
    return (dispatch) => {
        dispatch(fetchUsers());
        axios.get("https://jsonplaceholder.typicode.com/users").then(response => {
            dispatch(fetchSuccess(response.data))
        }).catch(error=> {
            dispatch(fetchFailure(error))
        })
    }
}

export {fetchUsers, fetchSuccess, fetchFailure, fetchAll};