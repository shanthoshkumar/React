import { FETCH_FAILURE, FETCH_SUCCESS, FETCH_USERS } from "./constants";
import { initialState } from "./state";

export const reducer = (state = initialState, action) => {
    switch (action.type) {
        case FETCH_USERS:
            return { ...state, loading: true };
        case FETCH_SUCCESS:
            return { ...state, loading: false, users: action.users };
        case FETCH_FAILURE:
            return { ...state, loading: false, error: action.error, users: [] }
        default: 
            return state
    }
}

