import {connect} from 'react-redux'
import { fetchAll } from '../redux/actions'
const PageTwo = (props) => {
    setTimeout(()=> {
     return <div> 
        <p>{props.noOfUsers}</p>
    </div>
    }, 5000)
}

const mapStateToProps = state => {
    return {
        noOfUsers: state.users.length,
    }
}

const mapDispatchToProps = dispatch => {
    return {
        fetchUsers: () => dispatch(fetchAll())
    }
}

export default connect(mapStateToProps, mapDispatchToProps)(PageTwo);
