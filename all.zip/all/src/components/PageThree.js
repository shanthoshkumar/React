import {connect} from 'react-redux'
import { fetchAll } from '../redux/actions'
const PageThree= (props) => {
    return <div> 
        <p>{props.noOfUsers}</p>
    </div>
}

const mapStateToProps = state => {
    return {
        noOfUsers: state.users.length,
    }
}

const mapDispatchToProps = dispatch => {
    return {
        fetchUsers: () => dispatch(fetchAll())
    }
}

export default connect(mapStateToProps, mapDispatchToProps)(PageThree);
