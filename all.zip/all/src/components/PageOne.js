import { useDispatch, useSelector} from 'react-redux'
import { fetchAll } from '../redux/actions';

const PageOne = () => {
    const dispatch = useDispatch();
    const noOfUsers = useSelector(state => state.users.length)
    return <div> 
        <p>{noOfUsers}</p>
        <button onClick={() => dispatch(fetchAll())}>Fetch</button>
    </div>
}

export default PageOne;
