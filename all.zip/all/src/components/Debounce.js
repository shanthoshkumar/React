import { useState } from "react"

const Debounce = () => {
    const [ text, setText ] = useState('');

    const debounce = (callbackFn ,delay) => {
        let timeout;
        return (...args)=>{
            clearTimeout(timeout);
            setTimeout(() => callbackFn(...args), delay);
        }

    }

    const updateText = debounce((text) => {
        setText(text)
    },2000)

    return <div>
        <input type='text'  onChange={(e) => updateText(e.target.value)}/>
        <h1>{text}</h1>
    </div>
}
export default Debounce