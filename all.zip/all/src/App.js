import logo from './logo.svg';
import './App.css';
import PageOne from './components/PageOne';
import {Provider} from 'react-redux'
import { store } from './redux/store';
import PageThree from './components/PageThree';
import PageFour from './components/PageFour';
import { lazy, Suspense } from 'react';
import Debounce from './components/Debounce';

const Page = lazy(() =>  import("./components/PageTwo"))

function App() {
  return (
    <div className="App">
      {/* <Provider store={store}>
        <Suspense fallback={<div>Loading....</div>}>
        <PageOne/>
        <Page></Page>
        <PageThree/>
        <PageFour/>
        </Suspense>
     </Provider> */}
     <Debounce/>
    </div>
  );
}

export default App;
