export const Card = ({ user, index }) => {
    return (
      <>
        <div className={`card ${index % 2 === 0 ? "even" : "odd"}`}>
          <div>{user.email}</div>
          <div>{user.address.zipcode}</div>
        </div>
      </>
    );
  };
  