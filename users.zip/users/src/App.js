import logo from './logo.svg';
import './App.css';
import { useEffect, useState } from "react";
import axios from "axios";
import { Card } from "./Card";

function App() {
  const [users, setUsers] = useState([]);
  useEffect(() => {
    axios
      .get("https://jsonplaceholder.typicode.com/users")
      .then((response) => {
        setUsers(response.data);
      })
      .catch((err) => console.error(err));
  }, []);

  const sortFn = (userObjA, userObjB) => {
    if (userObjA.email.length < userObjB.email.length) {
      return -1;
    }
    if (userObjA.email.length > userObjB.email.length) {
      return 1;
    }
    return 0;
  };

  const sortByEmail = (type) => {
    const sortedResult = users.sort(sortFn);
    const result = type === 0 ? sortedResult : sortedResult.reverse();
    setUsers([...result]);
  };

  return (
    <div className="App">
      <button onClick={() => sortByEmail(0)}>Ascending sort</button>
      <button onClick={() => sortByEmail(1)}>Descending sort</button>
      <div className="parent">
        {users.map((user, index) => (
          <Card key={user.email} user={user} index={index} />
        ))}
      </div>
    </div>
  );
}

export default App;
