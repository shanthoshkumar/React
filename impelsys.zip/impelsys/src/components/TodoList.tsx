import React, { useState } from 'react';
import Todo from './Todo';

const TodoList = () => {
  const [todoList, setTodoList] = useState<any>([]);
  const [todo, setTodo] = useState<string>();

  const setNewTodo = (e) => {
    setTodo(e.target.value);
  };

  const addTodo = () => {
    setTodoList([
      ...todoList,
      {
        index: todoList.length > 0 ? todoList.length + 1 : 1,
        title: todo,
        checked: false,
      },
    ]);
  };

  const updateTodo = (index) => {
    const updatedTodos = todoList.map((todo) => {
      if (todo.index === index) {
        todo.checked = !todo.checked;
      }
      return todo;
    });
    setTodoList([...updatedTodos]);
  };

  const deleteTodo = (index) => {
    const filteredTodos = todoList.filter((todo) => todo.index !== index);
    setTodoList([...filteredTodos]);
  };

  return (
    <div>
      <div className="input-container">
        <input type="text" onChange={setNewTodo} />
        <button onClick={addTodo} className="todobtn">
          Add todo
        </button>
      </div>
      <div className="todoList-container">
        {todoList.map((todo) => (
          <Todo
            key={todo.index}
            title={todo.title}
            index={todo.index}
            checked={todo.checked}
            update={updateTodo}
            deleteTodo={deleteTodo}
          />
        ))}
      </div>
    </div>
  );
};

export default TodoList;
