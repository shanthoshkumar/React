

type TodoProps = {
  title: string;
  index: number;
  checked: boolean;
  update: Function;
  deleteTodo: Function;
};

const Todo = ({ title, index, checked, update, deleteTodo }: TodoProps) => {
  return (
    <div className="todo-container">
      <input type="checkbox" onChange={() => update(index)} />
      <p className={checked && 'striked'}>{title}</p>
      <button className="deleteBtn" onClick={() => deleteTodo(index)}>
        Delete
      </button>
    </div>
  );
};

export default Todo;
