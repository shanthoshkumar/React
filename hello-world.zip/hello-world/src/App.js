import logo from './logo.svg';
import './App.css';
import {Greet} from './components/Greet';
import Welcome from './components/Welcome';
import Message from './components/Message';
import Counter from './components/Counter';
import Parent from './components/Parent';
import Persons from './components/Persons';
import StyleSheet from './components/StyleSheet';
import InlineStyle from './components/InlineStyle';
import ModuleStyle from './components/ModuleStyle'
import Form from './components/Form';
import SuperHero from './components/SuperHero';
import ErrorBoundary from './components/ErrorBoundary';
import ClickCounter from './components/ClickCounter';
import HoverCounter from './components/HoverCounter'
import {UserProvider} from './context/UserContext';
import DisplayContextValue from './components/DisplayContextValue';
import PostList from './components/PostList';
import UseStateHook from './components/UseStateHook';
import UseEffectHook from './components/UseEffectHook';
import ToggleDisplay from './components/ToggleDisplay';
import UseContextHook from './components/UseContextHook';
import UseReducerHook from './components/UseReducerHook';


function App() {
  return (
    <div className="App">
      {/* <Greet name="Bruce" heroName="Batman">
        <p>This is children</p>
      </Greet>
      <Greet name="Clark" heroName="Superman">
        <button>Click</button>
        </Greet>
      <Greet name="Diana" heroName="Spiderman"/>
      <Welcome name="Bruce" heroName="Batman"/>
      <Welcome name="Clark" heroName="Superman">
        <button>Click</button>
      </Welcome>
      <Welcome name="Diana" heroName="Spiderman"/> */}
      {/* <Message/>
      <Counter/>
      <Parent/>
      <Persons/>
      <StyleSheet/>
      <InlineStyle/>
      <ModuleStyle/>
      <Form/> */}
      {/* <ErrorBoundary>
      <SuperHero heroName = 'Superman'/>
      </ErrorBoundary>
      <ErrorBoundary>
      <SuperHero heroName = 'Spiderman'/>
      </ErrorBoundary>
      <ErrorBoundary>
      <SuperHero heroName = 'Batman'/>
      </ErrorBoundary>
      <ErrorBoundary>
      <SuperHero heroName = 'Joker'/>
      </ErrorBoundary>
      <ClickCounter name = 'Vishwas'/>
      <HoverCounter name = 'Vishwas'/>
      <UserProvider value = 'Vishwas'>
      <DisplayContextValue/>
      </UserProvider> */}
      {/* <PostList/> */}
      {/* <UseStateHook/>
      <UseEffectHook/> */}
      {/* <ToggleDisplay/> */}
      {/* <UserProvider value ='Vishwas'>
      <UseContextHook/>
      </UserProvider> */}
      <UseReducerHook/>
    </div>
  );
}

export default App;
