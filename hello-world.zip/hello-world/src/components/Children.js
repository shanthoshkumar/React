
export const Children = (props) => {
    return <button onClick = {() => props.greetParent('Alice')}>Greet</button>
}
