import {Component} from 'react';
import axios from 'axios';

class PostList extends Component{
    constructor(){
        super();
        this.state = {
            posts: [],
            postId: null
        }
    }

    fetchPostById(){
        axios.get(`https://jsonplaceholder.typicode.com/posts/${this.state.postId}`,).then(response => this.setState({posts: [response.data]}) ).catch(error => console.log(error))
    }

    render(){
        return (
        <div>
        <input type='text' onChange = {(e) => this.setState({postId: e.target.value})}/> 
        <button onClick={() => this.fetchPostById()}>Get Post</button>
            {
                this.state.posts.map(post => <h1 key ={post.id}>{post.title}</h1>)
            }
        </div>
        )
    }


    componentDidMount(){
        axios.get('https://jsonplaceholder.typicode.com/posts').then(response => this.setState({posts: response.data})).catch(error => console.log(error))
    }
}

export default PostList;