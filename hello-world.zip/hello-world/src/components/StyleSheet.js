import './styles/Style.css';
const Styling = () => {
    return <h1 className ='error'>Api failed!</h1>
}

export default Styling;