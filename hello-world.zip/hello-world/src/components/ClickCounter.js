import {Component} from 'react';
import WithCounter from './WithCounter';
class ClickCounter extends Component{
    constructor(){
        super();
    }

    render(){
        return (
            <div>
                <h1>{this.props.name} clicked {this.props.count} times </h1>
                <button onClick={this.props.incrementCount}>Click</button>
            </div>
        )
    }
}

export default WithCounter(ClickCounter);