const Person = (props) => <h1> My name is {props.name} and my age is {props.age}</h1>;

export default Person;