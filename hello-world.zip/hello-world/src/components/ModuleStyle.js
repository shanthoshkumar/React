import style from './styles/Style.module.css'
const ModuleStyle = () => {
    return (
    <div>
        <h1 className = {style.primary}> Processing Request... </h1>
    </div>)
}

export default ModuleStyle;