import {Component} from 'react';
import {Children} from './Children'
class Parent extends Component {
    constructor(){
        super()
    }
    greetParent(message){
        alert(`Hello parent i'm ${message}`)
    }

    render(){
        return <Children greetParent = {this.greetParent}/>
    }
}

export default Parent;