import Person from './Person';
const Persons = () => {

    const personList = [
        {name: 'Bruce', age: 24},
        {name: 'Clark', age: 25},
        {name: 'Diana', age: 26}

    ]
    return personList.map(person => <Person key={person.name} {...person}/> )
}

export default Persons;