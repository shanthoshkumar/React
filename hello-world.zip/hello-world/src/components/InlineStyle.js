const InlineStyle = () => {
    const style = {
        color: 'green',
        fontSize: '45px'
    }
    return  <h1 style = {style}>Api succeeded!</h1>
}

export default InlineStyle;