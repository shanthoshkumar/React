import {useContext} from 'react';
import {UserContext} from '../context/UserContext';

const UseContextHook = () => {
    return <h1>Hello {useContext(UserContext)}</h1>
}

export default UseContextHook;