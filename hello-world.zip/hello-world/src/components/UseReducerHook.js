import {useReducer} from 'react';

// Simple state and action
// const initialState = 0;
// const reducer = (state,action) => {
//     switch (action) {
//         case 'increment':
//                 return state + 1;
//             break;
//         case 'decrement':
//                 return state - 1;
//             break;
//         case 'reset':
//                 return 0;
//             break;
//         default:
//                return state;
//             break;
//     }
// }

// state as object
// const initialState = {
//     firstCount: 0,
//     secondCount: 0
// }
// const reducer = (state, action) => {
//     switch (action) {
//         case 'increment first':
//                 return {...state, firstCount : state.firstCount + 1}
//             break;
//         case 'decrement first':
//                 return {...state, firstCount: state.firstCount - 1}
//             break;
//         case 'increment second':
//             return {...state, secondCount : state.secondCount + 1}
//         break;
//         case 'decrement second':
//                 return {...state, secondCount: state.secondCount - 1}
//             break;
//         case 'reset':
//                 return { firstCount: 0, secondCount: 0}
//             break;
//         default:
//                 return state;
//             break;
//     }
// }


// state and action as object
const initialState = {
    firstCount: 0,
    secondCount: 0
}
const reducer = (state, action) => {
    switch (action.type) {
        case 'increment first':
                return {...state, firstCount : state.firstCount + action.value}
            break;
        case 'decrement first':
                return {...state, firstCount: state.firstCount -  action.value}
            break;
        case 'increment second':
            return {...state, secondCount : state.secondCount +  action.value}
        break;
        case 'decrement second':
                return {...state, secondCount: state.secondCount -  action.value}
            break;
        case 'reset':
                return { firstCount: 0, secondCount: 0}
            break;
        default:
                return state;
            break;
    }
}

const UseReducerHook = () => {
    const [count, dispatch] = useReducer(reducer, initialState);

    return (<>
    <div>
        {/* <h1>Count - {count}</h1>
        <button onClick={() => dispatch('increment')}>Increment</button>
        <button onClick={() => dispatch('decrement')}>Decrement</button>
        <button onClick={() => dispatch('reset')}>Reset</button> */}
          <h1>First Count - {count.firstCount}  Second  Count - {count.secondCount}</h1>
          <br/>
        <button onClick={() => dispatch({ type: 'increment first', value: 10})}>Increment First</button>
        <button onClick={() => dispatch({ type: 'decrement first', value: 1})}>Decrement First</button>
        <br/>
        <button onClick={() => dispatch({ type: 'increment second', value: 100})}>Increment Second</button>
        <button onClick={() => dispatch({ type: 'decrement second', value: 5})}>Decrement Second</button>
        <br/>
        <button onClick={() => dispatch({ type: 'reset'})}>Reset</button>
    </div>    
    </>)
}

export default UseReducerHook;