import {useState} from 'react';

const UseStateHook = () => {
    const [count, setCount] = useState(0);
    const [name, setName] = useState({firstName:'', lastName:''});
    const [items, setItem] = useState([])

    const addItem = () =>{
        setItem([
            ...items,
           Math.ceil(Math.random(0,10) * 10)
        ])
    }

    return (<div>
        <h1>Count - {count}</h1>
        <button onClick={() => setCount(count + 1)}>Increment</button>
        <button onClick={() => setCount(count - 1)}>Decrement</button>
        <br/>
        <hr/>
        <br/>
        <h1>{JSON.stringify(name)}</h1>
        <input type='text' onChange={(e) => setName({...name, firstName: e.target.value})}/> 
        <input type='text' onChange={(e) => setName({...name, lastName: e.target.value})}/>
        <br/>
        <hr/>
        <br/>
        <button onClick={addItem}>Add Item</button>
        {
            items.map((item, index) => <p key={index}>{item}</p>)
        }
        <br/>
        <hr/>
        <br/>
    </div>)
}

export default UseStateHook;