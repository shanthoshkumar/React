import {useState, useEffect} from 'react';
import axios from 'axios';

const UseEffectHook=()=>{
    const [count, setCount] = useState(0)
    const [x,setX] = useState(0)
    const [y, setY] = useState(0)
    const [posts, setPosts] = useState([])
    const [id, setId] = useState()
    const [idFromButtonClick, setIdFromButtonClick] = useState()

    useEffect(()=>{
        document.title = `You clicked ${count} times`
    })

    const logMousePosition = (e) =>{
        console.log(e);
        setX(e.clientX)
        setY(e.clientY)
    }

    useEffect(() => {
        console.log('Adding event listener ');
        window.addEventListener('mousemove', logMousePosition)

        return ()=>{
            console.log('Removing event listener ');
            window.removeEventListener('mousemove', logMousePosition)
        }
    },[])


    useEffect(() =>{
        console.log('Fetching posts');
        axios.get(`https://jsonplaceholder.typicode.com/posts`).then((response) => setPosts(response.data)).catch(error => console.log(error))
    },[])


    useEffect(() =>{
        console.log('Fetching posts');
        axios.get(`https://jsonplaceholder.typicode.com/posts/${id}`).then((response) => setPosts([response.data])).catch(error => console.log(error))
    },[idFromButtonClick])

    const setIdFromClick = () =>{
        setIdFromButtonClick(id)
    }
    return (<div>
        <h1>{document.title}</h1>
        <button onClick={() => setCount(count + 1)}>Update</button>
        <h1>Mouse position: {x} {y}</h1>
        <br/>
        <hr/>
        <br/>
        <input type='text' onChange={(e) => setId(e.target.value)}/> 
        <button onClick={setIdFromClick}>Get Post</button>
        {
            posts.map(post => {
                return <p key={post.id}>{post.title}</p>
            })
        }
    </div>)
}

export default UseEffectHook;