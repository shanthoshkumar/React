const SuperHero = (props) => {
    if(props.heroName === 'Joker') {
        throw new Error('Joker is not a super hero')
    }
    return <h1>{props.heroName}</h1>
}

export default SuperHero;