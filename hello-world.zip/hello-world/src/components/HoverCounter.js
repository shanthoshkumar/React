import {Component} from 'react';
import WithCounter from './WithCounter';
class HoverCounter extends Component{
    constructor(){
        super();
        }

        render(){
            return (
                <div>
                    <h1 onMouseOver={this.props.incrementCount}>{this.props.name} hovered {this.props.count} times</h1>
                </div>
            )
        }
}

export default WithCounter(HoverCounter);