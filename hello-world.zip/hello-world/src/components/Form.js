import {Component} from 'react';

class Form extends Component{
    constructor(){
        super();
        this.state = {
            username: '',
            address: '',
            skill: ''
        }
        this.changeHandler = this.changeHandler.bind(this)
    }

    changeHandler(event){
        this.setState({[event.target.name]: event.target.value})
    }

    submitForm = (event) => {
       alert(`${this.state.username} ${this.state.address} ${this.state.skill}`);
        event.preventDefault();
    }

    render(){
        return <form onSubmit={this.submitForm}>
            <div>
            <label>Username :</label>
                <input type='text' name="username" value={this.state.username} onChange={this.changeHandler}/>
            </div>
            <div>
                <label>Address :</label>
                <textarea  name="address" value={this.state.address} onChange={this.changeHandler}></textarea>
            </div>
            <div>
                <label>Skill :</label>
                <select name="skill" value={this.state.skill} onChange={this.changeHandler}>
                    <option value="React">React</option>
                    <option value="Angular">Angular</option>
                    <option value="Vue">Vue</option>
                </select>
            </div>
            <div>
                <button type="submit">submit</button>
            </div>
        </form>
    }
}

export default Form;