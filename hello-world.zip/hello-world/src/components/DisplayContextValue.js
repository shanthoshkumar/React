import {UserConsumer} from '../context/UserContext';

const DisplayContextValue = () => {
    return (
        <UserConsumer>
            {
                (username) => <h1> Hello {username}</h1>
            }
        </UserConsumer>
    )
}

export default DisplayContextValue;