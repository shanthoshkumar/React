import {useState} from 'react';
import UseEffectHook from './UseEffectHook';

const ToggleDisplay =()=>{
    const [visible, setVisibility] = useState(true)
    return (<div>
        <button onClick={() => setVisibility(!visible)}>Toggle display</button>
        {visible && <UseEffectHook/>}
        </div>)
}

export default ToggleDisplay;